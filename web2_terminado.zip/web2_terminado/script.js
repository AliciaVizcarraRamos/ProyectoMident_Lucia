function saludar(){
    alert("Hola mundo :) ");
    console.log("Hola mundo en consola");
}

function incrementar(){
    var contador=document.getElementById("contador").textContent;
    contador++;
    document.getElementById("contador").innerHTML=contador;
}

function decrementar(){
    var contador=document.getElementById("contador").textContent;
    contador--;
    document.getElementById("contador").innerHTML=contador;
}

// Permite volver a la página principal desde el logo
function goHome() {
    window.location.href = "index.html";
}

// Puedes agregar más funciones para otras interacciones aquí